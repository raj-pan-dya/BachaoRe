﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalMgmtSystem.Exceptions
{
    public class PatientException : ApplicationException   //User Defined Exception class
    {
        public PatientException()
            : base() { }

        public PatientException(string message)
            : base(message) { }
    }
}
