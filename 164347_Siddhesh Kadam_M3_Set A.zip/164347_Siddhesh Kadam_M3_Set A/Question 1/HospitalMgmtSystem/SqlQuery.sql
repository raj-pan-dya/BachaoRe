﻿CREATE TABLE [sidd_kadam].[Patient]
(
	[Id]	   INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[First_Name] VARCHAR(20) NULL,
	[Last_Name] VARCHAR(20) NULL,
	[Gender]   VARCHAR(10)  NULL,
	[Address]  VARCHAR(40)	 NULL,
	[City]  VARCHAR(15)	 NULL,
	[State]  VARCHAR(15)	 NULL,
	[Pin_Code]  INT	 NULL,
	[Phone_Number]  VARCHAR(15)	 NULL,
);

CREATE PROCEDURE [sidd_kadam].[USP_AddDetails]
	@fName VARCHAR(20), 
	@lName VARCHAR(20),
	@gender VARCHAR(10),
	@address  VARCHAR(40),
	@city  VARCHAR(15),
	@state  VARCHAR(15),
	@pin  INT,
	@phoneNo VARCHAR(15)
AS 
BEGIN
INSERT INTO [sidd_kadam].[Patient] 
VALUES(@fName, @lName, @gender, @address, @city, @state, @pin, @phoneNo)
END

SELECT * FROM [sidd_kadam].[Patient]