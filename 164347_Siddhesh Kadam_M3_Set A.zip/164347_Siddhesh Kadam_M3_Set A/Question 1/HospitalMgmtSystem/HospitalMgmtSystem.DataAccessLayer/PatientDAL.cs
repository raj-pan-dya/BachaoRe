﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using HospitalMgmtSystem.Entities;
using HospitalMgmtSystem.Exceptions;

namespace HospitalMgmtSystem.DataAccessLayer
{
    public class PatientDAL
    {
        /* Declaring SqlConnection object reference */
        SqlConnection con = null;

        /* Declaring SqlCommand object reference */
        SqlCommand cmd = null;

        /* Declaring Data Reader object reference */
        SqlDataReader dr = null;

        //To establish connection to server
        public PatientDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);
        }

        //Logic for Submitting details
        public bool SubmitDAL(Patient patient)
        {
            bool submitted = false;
            try
            {
                cmd = new SqlCommand("[sidd_kadam].[USP_AddDetails]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@fName", patient.FirstName);
                cmd.Parameters.AddWithValue("@lName", patient.LastName);
                cmd.Parameters.AddWithValue("@gender", patient.Gender);
                cmd.Parameters.AddWithValue("@address", patient.Address);
                cmd.Parameters.AddWithValue("@city", patient.City);
                cmd.Parameters.AddWithValue("@state", patient.State);
                cmd.Parameters.AddWithValue("@pin", patient.PinCode);
                cmd.Parameters.AddWithValue("@phoneNo", patient.PhoneNo);
                con.Open();
                cmd.ExecuteNonQuery();
                submitted = true;
            }
            catch (PatientException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)     //To close connection if open
                { con.Close(); }
            }
            return submitted;
        }
    }
}
