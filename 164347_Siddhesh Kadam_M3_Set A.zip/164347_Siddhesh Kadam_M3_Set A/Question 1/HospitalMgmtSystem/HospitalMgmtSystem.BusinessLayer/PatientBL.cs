﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalMgmtSystem.Entities;
using HospitalMgmtSystem.Exceptions;
using HospitalMgmtSystem.DataAccessLayer;

namespace HospitalMgmtSystem.BusinessLayer
{
    public class PatientBL
    {
        //Logic for validitaions
        private static bool ValidInfo(Patient patient)
        {
            StringBuilder sbldr = new StringBuilder();
            bool validInfo = true;

            if (patient.PhoneNo.Length != 10)
            {
                validInfo = false;
                sbldr.Append(Environment.NewLine + "Phone number should have 10 digits!");
            }

            if (patient.PinCode.ToString().Length != 6)
            {
                validInfo = false;
                sbldr.Append(Environment.NewLine + "Pin code should have 6 digits!");
            }  
            
            if (validInfo == false)
            { throw new PatientException(sbldr.ToString()); }

            return validInfo;
        }

        //Logic for validations of DAL
        public bool SubmitBL(Patient patient)
        {
            bool submitted = false;

            try
            {
                if (ValidInfo(patient))
                {
                    PatientDAL patientDAL = new PatientDAL();
                    submitted = patientDAL.SubmitDAL(patient);
                }
            }
            catch (PatientException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return submitted;
        }
    }
}
