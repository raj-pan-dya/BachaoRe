﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityFrameWorkPatient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null; //Declaring database context with null

        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities(); //initializing database context
        }

        public void DisplayPatients()
        {
            List<Patient> patients = dbContext.Patients.ToList();
            var pat = patients.Where(p => p.State == "Maharashtra"); //Condition for patient details from Maharashtra
            dataGrdPatient.ItemsSource = pat;     //populating UI       
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) { DisplayPatients(); } //Display details in UI
    }
}
