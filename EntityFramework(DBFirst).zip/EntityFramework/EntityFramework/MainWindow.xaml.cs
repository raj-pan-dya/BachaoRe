﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityFramework
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;        

        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        public void PopulateUI()
        {
            List<Product> prods = dbContext.Products.ToList();
           
            dgProd.ItemsSource = prods;
            comboBox.ItemsSource = prods;
            comboBox.DisplayMemberPath = "ProdName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) { PopulateUI(); }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            Product prod = new Product();

            /* code to get data from controls & set to properties of products */
            prod.ProdName = comboBox.Text;
            prod.Price = Convert.ToDecimal(txtBoxPrice.Text);
            prod.ExpDate = Convert.ToDateTime(expDate.Text);

            dbContext.Products.Add(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted!");
            PopulateUI();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Product product = dbContext.Products.Single(p => p.Id == id);
            product.ProdName = comboBox.Text;
            product.Price = Convert.ToDecimal(txtBoxPrice.Text);
            product.ExpDate = Convert.ToDateTime(expDate.Text);
            dbContext.SaveChanges();
            MessageBox.Show("Updated!");
            PopulateUI();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            /* code to get id of the product */
            int id = ((Product)comboBox.SelectedItem).Id;

            /* LINQ code to select single item from item list */
            Product prod = dbContext.Products.Single(p => p.Id == id);

            dbContext.Products.Remove(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Deleted!");
            PopulateUI();
        }

        int id;

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            id = ((Product)comboBox.SelectedItem).Id;
        }
    }
}
