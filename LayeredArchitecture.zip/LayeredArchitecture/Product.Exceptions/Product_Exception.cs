﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Product.Exceptions
{
    public class Product_Exception : ApplicationException
    {
        public Product_Exception()
            : base()
        {
        }
        public Product_Exception(string msg)
            : base(msg)
        {
        }
    }
}
