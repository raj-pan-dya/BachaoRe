﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Product.Entity;
using Product.Exceptions;
using Product.BusinessLayer;

namespace Product.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductBL proBL = new ProductBL();
        Product1 proTemp = null; // this is for edit button

        public MainWindow()
        {
            InitializeComponent();
        }


        public void DisplayUI()
        {
            try
            {
                IEnumerable<Product1> prods = proBL.SelectBL();
                gridProducts.ItemsSource = prods;
                prodName.ItemsSource = prods;
                prodName.DisplayMemberPath = "ProdName";
                
            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                throw;
            }
        }


        private bool IsValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (prodName.Text == null | prodName.Text == string.Empty | prodName.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                isValid = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty | txtPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (txtDate.Text.ToString() == null | txtDate.Text == string.Empty | txtDate.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new Product_Exception(sb.ToString());
            }

            return isValid;
          
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayUI();
        }

        private void Btn_insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsValid())
                {
                    Product1 pro = new Product1
                    {
                        ProdName = prodName.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(txtDate.Text)

                    };
               
                    proBL.InsertBL(pro);
                    MessageBox.Show("Inserted Succesfully");
                    DisplayUI();
                }

            }
            catch(Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                 MessageBox.Show(ex.Message);
               
            }
        }

        private void Btn_update_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (IsValid())
                {
                    proTemp.ProdName = prodName.Text;
                    proTemp.Price = Convert.ToDecimal(txtPrice.Text);
                    proTemp.ExpDate = Convert.ToDateTime(txtDate.Text);
                    proBL.UpdateBL(proTemp);
                    MessageBox.Show("Update Succesfully");
                    DisplayUI();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }

        }

        private void Btn_delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsValid())
                {
                    proTemp = (Product1)prodName.SelectedItem;

                    proBL.DeleteBL(proTemp.Id);
                    MessageBox.Show("Deleted Succesfully");
                    DisplayUI();
                }

            }
            catch (Product_Exception ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //This is Edit button
           
                proTemp = (Product1)prodName.SelectedItem;
           
        }
    }
}
