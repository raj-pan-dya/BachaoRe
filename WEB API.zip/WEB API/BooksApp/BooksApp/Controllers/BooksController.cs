﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BooksApp.Models;

namespace BooksApp.Controllers
{
    public class BooksController : ApiController
    {
        List<Book> bookList = new List<Book>()
        {
            new Book{ID=123,Title="C#",Genre="Programming",Year=2013,Price=999},
            new Book{ID=124,Title=".NET",Genre="Programming",Year=2018,Price=1999},
            new Book{ID=123,Title="MVC",Genre="Programming",Year=2014,Price=1544},
        };

        // GET: api/Books
        public IEnumerable<Book> Get()
        {
            return bookList;
        }

        public void PostBook(Book book)
        {
            if (book == null)
            {
                throw new ArgumentException("Invalid Object");
            }
            bookList.Add(book);
        }

        public void DeleteBook(int id)
        {
            bookList.RemoveAll(b => b.ID == id);
        }
    }
}
