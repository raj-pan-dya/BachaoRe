﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Module4CRUD.Models;
using System.Data.Entity;
using System.Net;
namespace Module4CRUD.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        TrainingEntities db = new TrainingEntities();
        public ActionResult Index()
        {
            return View(db.Student_master.ToList());
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create([Bind(Include = "Stud_Code,Stud_Name,Dept_Code,Stud_Dob,Address")] Student_master student_master)
        {
            if (ModelState.IsValid)
            {
                db.Student_master.Add(student_master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(student_master);
        }




    }
}