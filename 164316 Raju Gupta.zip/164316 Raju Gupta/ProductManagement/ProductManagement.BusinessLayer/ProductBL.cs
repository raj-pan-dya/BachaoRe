﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductManagement.DAL;
using Product.Entity;
using ProductManagement.Exceptionss;

namespace ProductManagement.BusinessLayer
{
    public class ProductBL
    {
        private static bool IsInputValid(Products product)
        {
            StringBuilder sb = new StringBuilder();
            bool validProduct = true;
            if (product.ProdName.Length < 2)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Product Name Invalid");

            }
            if (product.Price < 0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Price Value");

            }

            if (product.ExpDate.Date.ToString() == (DateTime.Now.Date).ToString())
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Expired Product");
            }
            if (validProduct == false)
                throw new Exceptions(sb.ToString());

            return validProduct;
        }
        //BL Method to insert data in product table using Stored Procedure 

        public bool InsertBL(Products product)
        {
            bool isInserted = false;
            try
            {
                if (IsInputValid(product))
                {
                    ProductDAL proDAL = new ProductDAL();
                    isInserted = proDAL.InsertDAL(product);

                }

            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isInserted;
        }


        //BL Method to Update data in product table using Stored Procedure 

        public bool UpdateBL(Products product)
        {
            bool isUpdated = false;
            try
            {
                if (IsInputValid(product))
                {
                    ProductDAL proDAL = new ProductDAL();
                    isUpdated = proDAL.UpdateDAL(product);

                }
            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isUpdated;
        }

        //BL Method to Delete data from product table using Stored Procedure 

        public bool DeleteBL(int id)
        {
            bool isDeleted = false;

            try
            {
                ProductDAL proDAL = new ProductDAL();
                isDeleted = proDAL.DeleteDAL(id);

            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isDeleted;
        }

        //BL Method to Select and populate data from product table 

        public IEnumerable<Products> SelectBL()
        {
            IEnumerable<Products> products = null;
            try
            {

                ProductDAL proDL = new ProductDAL();
                products = proDL.SelectDAL();

            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }

            return products;

        }

    }
}
