﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductManagement.Exceptionss;
using Product.Entity;
using System.Data.SqlClient;
using System.Configuration;

namespace ProductManagement.DAL
{
    public class ProductDAL
    {
        //Declaring SqlConnection object reference
        SqlConnection cn = null;
        //Declaring SqlCommand object reference
        SqlCommand cmd = null;

        //Declaring Data Reader object reference
        SqlDataReader dr = null;

        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        }

        //DAL Method to insert data in product table using Stored Procedure 

        public bool InsertDAL(Products product)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("Amit.USP_ProductInsert", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pname", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }
            
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return isInserted;
        }


        //DAL Method to Update data in product table using Stored Procedure 

        public bool UpdateDAL(Products product)
        {
            bool isUpdated = false;

            try

            {
                cmd = new SqlCommand("Amit.USP_ProductUpdate", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pname", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return isUpdated;
        }


        //DAL Method to Delete data from product table using Stored Procedure 

        public bool DeleteDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                cmd = new SqlCommand("Amit.USP_ProductDelete", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                cmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

            return isDeleted;
        }

        //DAL Method to Select and populate data from product table 

        public IEnumerable<Products> SelectDAL()
        {
            List<Products> products = new List<Products>();
            try
            {
                cmd = new SqlCommand("select * from Amit.Product", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Products p = new Products();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();

            }
            catch (Exceptions ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return products;
        }
    }
}
    