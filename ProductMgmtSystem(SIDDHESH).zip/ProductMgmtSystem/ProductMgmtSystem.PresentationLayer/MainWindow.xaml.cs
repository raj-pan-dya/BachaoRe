﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProductMgmtSystem.Entities;
using ProductMgmtSystem.Exceptions;
using ProductMgmtSystem.BusinessLayer;

namespace ProductMgmtSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Product prodTemp = null; /* For EDIT Button */
        Product product = null;
        ProductBL productBL = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void DisplayInUI()
        {
            try
            {
                productBL = new ProductBL();
                IEnumerable<Product> products = productBL.SelectBL();
                dataGridRecords.ItemsSource = products;
                cmbBoxProdName.ItemsSource = products;
                cmbBoxProdName.DisplayMemberPath = "ProdName";
            }
            catch (ProductException udEx)
            {
                MessageBox.Show(udEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayInUI();
        }

        private bool ValidProduct()
        {
            bool prodValid = true;
            StringBuilder sb = new StringBuilder();

            if (cmbBoxProdName.Text == null | cmbBoxProdName.Text == string.Empty | cmbBoxProdName.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter product name!");
                prodValid = false;
            }
            if (txtBoxPrice.Text == null | txtBoxPrice.Text == string.Empty | txtBoxPrice.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the price!");
                prodValid = false;
            }
            if (datePkrExpDate.Text.ToString() == null | datePkrExpDate.Text == string.Empty | datePkrExpDate.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the expiry date!");
                prodValid = false;
            }
            if (prodValid == false)
            {
                throw new ProductException(sb.ToString());
            }
            return prodValid;
        }        

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidProduct())
                {
                    productBL = new ProductBL();
                    product = new Product                    
                    {
                        ProdName = cmbBoxProdName.Text,
                        Price = Convert.ToDecimal(txtBoxPrice.Text),
                        ExpDate = Convert.ToDateTime(datePkrExpDate.Text)
                    };
                    productBL.InsertBL(product);
                    MessageBox.Show("Record inserted succesfully!");
                    DisplayInUI();
                }
            }
            catch (ProductException udEx)
            {
                MessageBox.Show(udEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidProduct())
                {
                    prodTemp.ProdName = cmbBoxProdName.Text;
                    prodTemp.Price = Convert.ToDecimal(txtBoxPrice.Text);
                    prodTemp.ExpDate = Convert.ToDateTime(datePkrExpDate.Text);
                    productBL.UpdateBL(prodTemp);
                    MessageBox.Show("Record updated succesfully!");
                    DisplayInUI();
                }
            }
            catch (ProductException udEx)
            {
                MessageBox.Show(udEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            prodTemp = (Product)cmbBoxProdName.SelectedItem;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidProduct())
                {
                    product = (Product)cmbBoxProdName.SelectedItem;

                    productBL.DeleteBL(product.Id);
                    MessageBox.Show("Record deleted succesfully!");
                    DisplayInUI();
                }
            }
            catch (ProductException udEx)
            {
                MessageBox.Show(udEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
