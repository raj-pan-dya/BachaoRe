﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductMgmtSystem.Entities;
using ProductMgmtSystem.Exceptions;
using System.Data;


namespace ProductMgmtSystem.DataAccessLayer
{
    public class ProductDAL
    {
        /* Declaring SqlConnection object reference */
        SqlConnection con = null;

        /* Declaring SqlCommand object reference */
        SqlCommand cmd = null;

        /* Declaring Data Reader object reference */
        SqlDataReader dr = null;

        public ProductDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);
        }

        public bool InsertDAL(Product product)
        {
            bool prodInserted = false;
            try
            {
                cmd = new SqlCommand("[sidd_kadam].[USP_InsertProduct]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                con.Open();
                cmd.ExecuteNonQuery();
                prodInserted = true;
            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                { con.Close(); }
            }
            return prodInserted;
        }

        public bool UpdateDAL(Product product)
        {
            bool prodUpdated = false;

            try

            {
                cmd = new SqlCommand("[sidd_kadam].[USP_UpdateProduct]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                con.Open();
                cmd.ExecuteNonQuery();
                prodUpdated = true;
            }
            catch (ProductException ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return prodUpdated;
        }

        public bool DeleteDAL(int id)
        {
            bool prodDeleted = false;
            try
            {
                cmd = new SqlCommand("[sidd_kadam].[USP_DeleteProduct]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                prodDeleted = true;
            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return prodDeleted;
        }

        public IEnumerable<Product> SelectDAL()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand("SELECT * FROM [sidd_kadam].[Product]", con);
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();

            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                { con.Close(); }
            }
            return products;
        }
    }
}
