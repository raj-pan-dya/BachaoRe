﻿CREATE TABLE [sidd_kadam].[Product]
(
	[Id]	   INT IDENTITY(1, 1) PRIMARY KEY NOT NULL,
	[ProdName] VARCHAR(20) NULL,
	[Price]    DECIMAL(18) NULL,
	[ExpDate]  DATE		   NULL
);


INSERT INTO sidd_kadam.Product(ProdName, Price, ExpDate)
VALUES
('Paste', 23.098, '08/23/2020'),
('Oil', 110.899, '01/30/2022'),
('Cheese', 40.53, '02/15/2019')


CREATE PROCEDURE [sidd_kadam].[USP_InsertProduct]
	@pName VARCHAR(20), 
	@price DECIMAL(18),
	@eDate DATE
AS 
INSERT INTO [sidd_kadam].[Product] 
VALUES(@pName, @price, @eDate)


CREATE PROCEDURE [sidd_kadam].[USP_UpdateProduct]
	@id INT,
	@pName VARCHAR(20), 
	@price DECIMAL(18),
	@eDate DATE
AS
UPDATE [sidd_kadam].[Product]
SET ProdName=@pName, Price=@price, ExpDate=@eDate 
WHERE Id=@id


CREATE PROCEDURE [sidd_kadam].[USP_DeleteProduct]
	@id INT
AS
DELETE FROM [sidd_kadam].[Product] 
WHERE Id=@id 

SELECT * FROM [sidd_kadam].[Product]
