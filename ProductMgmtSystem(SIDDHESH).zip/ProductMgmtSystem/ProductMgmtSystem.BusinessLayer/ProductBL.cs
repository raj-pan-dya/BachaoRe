﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductMgmtSystem.Entities;
using ProductMgmtSystem.Exceptions;
using ProductMgmtSystem.DataAccessLayer;

namespace ProductMgmtSystem.BusinessLayer
{
    public class ProductBL
    {
        private static bool ValidInput(Product product)
        {
            StringBuilder sb = new StringBuilder();
            bool validProduct = true;
            if (product.ProdName.Length < 2)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Product Name!");

            }
            if (product.Price <= 0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Price Value!");

            }
            if (product.ExpDate.Date <= (DateTime.Now.Date))
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Expired Product!");
            }
            if (validProduct == false)
            { throw new ProductException(sb.ToString()); }

            return validProduct;
        }

        public bool InsertBL(Product product)
        {
            bool prodInserted = false;
            try
            {
                if (ValidInput(product))
                {
                    ProductDAL productDAL = new ProductDAL();
                    prodInserted = productDAL.InsertDAL(product);
                }
            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }            
            return prodInserted;
        }

        public bool UpdateBL(Product product)
        {
            bool prodUpdated = false;
            try
            {
                if (ValidInput(product))
                {
                    ProductDAL productDAL = new ProductDAL();
                    prodUpdated = productDAL.UpdateDAL(product);
                }
            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return prodUpdated;
        }

        public bool DeleteBL(int id)
        {
            bool prodDeleted = false;

            try
            {
                ProductDAL productDAL = new ProductDAL();
                prodDeleted = productDAL.DeleteDAL(id);

            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return prodDeleted;
        }

        public IEnumerable<Product> SelectBL()
        {
            IEnumerable<Product> products = null;
            try
            {
                ProductDAL productDL = new ProductDAL();
                products = productDL.SelectDAL();
            }
            catch (ProductException udEx)
            {
                throw udEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return products;
        }
    }
}
