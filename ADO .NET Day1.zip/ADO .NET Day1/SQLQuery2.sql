﻿create table [rudrendra_rud].[Product](
[Id] INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
[ProdName] VARCHAR(20) NULL,
[Price] DECIMAL(18) NULL,
[ExpDate] DATE NULL

);

--insert
INSERT INTO [rudrendra_rud].[Product](ProdName,Price,ExpDate) VALUES ('Cadbury',100,'12/31/2018'),('Biscuit',200,'12/12/2018'),('Oil',200,'10/12/2018');

--update
update rudrendra_rud.Product
SET ProdName= 'Game' where Id=2;

insert into [rudrendra_rud].[Product] values (@pName, @price, @eDate);

--drop table rudrendra_rud.Product;

SELECT * FROM [rudrendra_rud].[Product];

create proc [rudrendra_rud].USP_InsertProduct
	@pName VARCHAR(20),
	@price DECIMAL(18),
	@eDate DATE
as
insert into [rudrendra_rud].[Product] values (@pName, @price, @eDate)

drop proc [rudrendra_rud].USP_UpdateProduct

create proc [rudrendra_rud].USP_UpdateProduct
	@id int,
	@pName VARCHAR(20),
	@price DECIMAL(18),
	@eDate DATEtime

as
update [rudrendra_rud].[Product]
set 
	--Id=@id,
	ProdName = @pName,
	Price=@price,
	ExpDate=@eDate
where Id=@id;

create proc [rudrendra_rud].USP_DeleteProduct
@id int
as
delete from [rudrendra_rud].Product where Id=@id;
	
