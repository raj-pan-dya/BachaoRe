﻿create schema rudrendra_rud

