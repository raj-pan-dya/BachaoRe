﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace ProductMaintenanceSystem
{
    [Serializable]
    internal class PMSException : Exception
    {
        public PMSException()
        {

        }
        public PMSException(string message): base(message)
        {

        }
        public PMSException(string message,Exception innerException) : base(message,innerException)
        {

        } 
        protected PMSException(SerializationInfo info,StreamingContext context):base(info,context)
        {

        }
    }
}
