﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;



namespace ProductMaintenanceSystem
{
    public class ProductDAL//vimp public
    {
        //variable declartion of Sql classes
        SqlConnection cn = null;//will be common 
        SqlCommand cmd = null;//it will change so instantiate seperatly.

        SqlDataReader dr = null;

        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);

        }


     

        public void Insert(Product product)
        {
            try
            {
                // cmd = new SqlCommand("insert into [rudrendra_rud].[Product] values (@pName, @price, @eDate)", cn);
                cmd = new SqlCommand("[rudrendra_rud].USP_InsertProduct", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;//VIMP
                //add parameters into command list

                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);

                cn.Open();
                cmd.ExecuteNonQuery();//returns no of rows as int can be storeed
                //dont close conn here
                
            }
            catch (PMSException ex1)
            {
                throw ;
            }

            catch (Exception ex2)
            {
                throw;
            }
            

            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
                //Used to Close Connection
            }
        }

        public void Update(Product product)
        {
            try
            {
                cmd = new SqlCommand("[rudrendra_rud].USP_UpdateProduct", cn);
                //cmd = new SqlCommand("amol.USP_UpdateProduct", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pName", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();

            }
            catch (PMSException ex1)
            {
                throw ex1;
            }
            catch(Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

        public void Delete(int id)
        {
            try
            {
                cmd = new SqlCommand("[rudrendra_rud].USP_DeleteProduct", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (PMSException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }

        }

        public IEnumerable<Product> SelectAll()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand("select * from [rudrendra_rud].[Product]", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();
            }
            catch(PMSException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return products;
        }
    }
}
