﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProductMaintenanceSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductDAL dal = new ProductDAL();
        Product p = null;

        public MainWindow()
        {
            InitializeComponent();
        }

        public bool isInputValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if(comboBox.Text==null | comboBox.Text==string.Empty | comboBox.Text.Length < 1)
            {
                sb.Append("\n Product name is Mandatory");
                isValid = false;
            }
            if(txtBox.Text==null | txtBox.Text==string.Empty | txtBox.Text.Length < 1)
            {
                sb.Append("\n Product-Price is Mandatory");
                isValid = false;
            }
            if(datePicker.Text==null | datePicker.Text==string.Empty | datePicker.Text.Length < 1)
            {
                sb.Append("\n Expiry Date is Mandatory");
                isValid = false;
            }
            if(!isValid)
            {
                throw new PMSException(sb.ToString());
            }
            return isValid;
        }

        public void PopulateUI()
        {
            IEnumerable<Product> prods = dal.SelectAll();
            dgProducts.ItemsSource = prods;
            comboBox.ItemsSource = prods;
            comboBox.DisplayMemberPath = "ProdName";
        }


        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (isInputValid()==true)
                {
                    Product p = new Product
                    {
                        ProdName = comboBox.Text,
                        Price = Convert.ToDecimal(txtBox.Text),
                        ExpDate = Convert.ToDateTime(datePicker.Text)
                    };
                    dal.Insert(p);
                    MessageBox.Show("Insert");
                    PopulateUI();
                }
            }
            catch (PMSException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }
                  
        
       

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

               // Product p = (Product)comboBox.SelectedItem;
                p.ProdName = comboBox.Text.ToString();
                p.Price = Convert.ToDecimal(txtBox.Text);
                p.ExpDate = Convert.ToDateTime(datePicker.Text);
                dal.Update(p);
                MessageBox.Show("Updated");
                PopulateUI();
                //if(isInputValid()==true)
                //{
                //    Product p = new Product
                //    {
                //        ProdName = comboBox.Text,
                //        Price = Convert.ToInt32(txtBox.Text),
                //        ExpDate = Convert.ToDateTime(datePicker.Text)
                //    };
                //    dal.Update(p);
                //    MessageBox.Show("Updated");
                //}

            }
            catch (PMSException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch(Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Product prd = (Product)comboBox.SelectedItem;
            try {
                dal.Delete(prd.Id);
                MessageBox.Show("Deleted");
                PopulateUI();
            }
            catch(PMSException ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }



        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Product p = (Product)comboBox.SelectedItem;

            //MessageBox.Show(p.Id.ToString());
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            p = (Product)comboBox.SelectedItem;
        }
    }
}
