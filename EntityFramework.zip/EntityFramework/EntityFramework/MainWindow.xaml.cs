﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityFramework
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        Training_24Oct18_PuneEntities dbContext = null;
       
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        public void DisplayUI()
        {
            List<Patient> pat = dbContext.Patients.ToList();
            var res = pat.Where(p => p.STATE.Equals("Maharastra"));
            patients.ItemsSource = res;
           
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayUI();
        }
    }
}
