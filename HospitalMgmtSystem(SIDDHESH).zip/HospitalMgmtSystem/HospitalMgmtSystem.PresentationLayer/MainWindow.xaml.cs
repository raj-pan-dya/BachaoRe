﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HospitalMgmtSystem.Entities;
using HospitalMgmtSystem.Exceptions;
using HospitalMgmtSystem.BusinessLayer;

namespace HospitalMgmtSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Patient patient = null;
        PatientBL patientBL = null;
        string gender;

        public MainWindow()
        {
            InitializeComponent();
        }

        private bool ValidInfo()
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (txtBoxFirstName.Text == null | txtBoxFirstName.Text == string.Empty | txtBoxFirstName.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter your first name!");
                valid = false;
            }
            if (txtBoxLastName.Text == null | txtBoxLastName.Text == string.Empty | txtBoxLastName.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter your last name!");
                valid = false;
            }
            if (txtBoxAddress.Text == null | txtBoxAddress.Text == string.Empty | txtBoxAddress.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the address!");
                valid = false;
            }
            if (txtBoxCity.Text == null | txtBoxCity.Text == string.Empty | txtBoxCity.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the city name!");
                valid = false;
            }
            if (txtBoxState.Text == null | txtBoxState.Text == string.Empty | txtBoxState.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the state!");
                valid = false;
            }
            if (txtBoxPinCode.Text == null | txtBoxPinCode.Text == string.Empty | txtBoxPinCode.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter the pin code!");
                valid = false;
            }
            if (txtBoxPhoneNo.Text == null | txtBoxPhoneNo.Text == string.Empty | txtBoxPhoneNo.Text.Length < 1)
            {
                sb.Append(Environment.NewLine + "Please enter your phone number!");
                valid = false;
            }
            if (valid == false)
            {
                throw new PatientException(sb.ToString());
            }
            return valid;
        }

        private void radioBtnMale_Click_1(object sender, RoutedEventArgs e)
        {
            if (radioBtnMale.IsChecked == true)
            {
                gender = radioBtnMale.Content.ToString();
            }
        }

        private void radioBtnFemale_Click(object sender, RoutedEventArgs e)
        {
            if (radioBtnFemale.IsChecked == true)
            {
                gender = radioBtnFemale.Content.ToString();
            }
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidInfo())
                {
                    patientBL = new PatientBL();
                    patient = new Patient
                    {
                        FirstName = txtBoxFirstName.Text,
                        LastName = txtBoxLastName.Text,
                        Gender = gender,
                        Address = txtBoxAddress.Text,
                        City = txtBoxCity.Text,
                        State = txtBoxState.Text,
                        PinCode = Convert.ToInt32(txtBoxPinCode.Text),
                        PhoneNo = txtBoxPhoneNo.Text,
                    };
                    patientBL.SubmitBL(patient);
                    MessageBox.Show("Patient details registered successfully!");
                    txtBoxFirstName.Text = string.Empty;
                    txtBoxLastName.Text = string.Empty;
                    txtBoxAddress.Text = string.Empty;
                    txtBoxCity.Text = string.Empty;
                    txtBoxState.Text = string.Empty;
                    txtBoxPinCode.Text = string.Empty;
                    txtBoxPhoneNo.Text = string.Empty;
                    radioBtnMale.IsChecked = false; 
                    radioBtnFemale.IsChecked = false; 
                }
            }
            catch (PatientException udEx)
            {
                MessageBox.Show(udEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }        
    }
}
