﻿///<summary>
///      File                 : 
///      Author Name          : Amit Potdar
///      Desc                 : Program to define the Entities of the project.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product.Entity
{
    public class Product1
    {
        public int Id { get; set; }
        public string ProdName { get; set; }
        public decimal Price { get; set; }
        public DateTime ExpDate { get; set; }
    }
}
