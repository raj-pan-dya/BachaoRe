﻿///<summary>
///      File                 : 
///      Author Name          : Amit Potdar
///      Desc                 : Program for Business Logic
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product.Entity;
using Product.Exceptions;
using Product.DataAccessLayer;

namespace Product.BusinessLayer
{
    public class ProductBL
    {

        private static bool IsInputValid(Product1 product)
        {
            StringBuilder sb = new StringBuilder();
             bool validProduct = true;
            if (product.ProdName.Length < 2)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Product Name Invalid");

            }
            if (product.Price<0)
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Invalid Price Value");

            }

            if (product.ExpDate.Date.ToString()==(DateTime.Now.Date).ToString())
            {
                validProduct = false;
                sb.Append(Environment.NewLine + "Expired Product");
            }
             if (validProduct == false)
                throw new Product_Exception(sb.ToString());
                
            return validProduct;
        }
        //BL Method to insert data in product table using Stored Procedure 

        public static bool InsertBL(Product1 product)
        {
            bool isInserted = false;
            try
            {
                if (IsInputValid(product))
                {
                    ProductDAL proDAL = new ProductDAL();
                    isInserted = proDAL.InsertDAL(product);

                }

            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
           
            return isInserted;
        }

        //BL Method to Update data in product table using Stored Procedure 

        public static bool UpdateBL(Product1 product)
        {
            bool isUpdated = false; 
            try
            {
                if (IsInputValid(product))
                {
                    ProductDAL proDAL = new ProductDAL();
                    isUpdated = proDAL.UpdateDAL(product);
                     
                }
            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
         
            return isUpdated;
        }

        //BL Method to Delete data from product table using Stored Procedure 

        public static bool DeleteBL(int id)
        {
            bool isDeleted = false;

            try
            {
                ProductDAL proDAL = new ProductDAL();
                isDeleted = proDAL.DeleteDAL(id);
                
            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
           
            return isDeleted;
        }

        //BL Method to Select and populate data from product table 

        public static IEnumerable<Product1> SelectBL()
        {
            IEnumerable<Product1> products = null;
            try
            {
                
                ProductDAL proDL = new ProductDAL();
                products = proDL.SelectDAL();
               
            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            
            return products;

        }
    }
}
