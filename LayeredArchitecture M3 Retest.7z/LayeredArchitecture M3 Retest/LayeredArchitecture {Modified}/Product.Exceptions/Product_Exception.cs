﻿///<summary>
///      File                 : 
///      Author Name          : Amit Potdar
///      Desc                 : Manual Exceptions implemented
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Product.Exceptions
{
    public class Product_Exception : ApplicationException
    {
        public Product_Exception()
            : base()
        {
        }
        public Product_Exception(string msg)
            : base(msg)
        {
        }
    }
}
