﻿create schema Amit;

create table [Amit].[Product] (
[Id] int identity (1,1) primary key not null,
[ProdName] varchar (20) null,
[Price] Decimal (18) null,
[ExpDate] Date null
);
use Training_24Oct18_Pune
INSERT INTO Amit.Product  VALUES('Amit',50,'12/12/2018'),('Sumit',60,'12/22/2018')

select * from Amit.Product

update Amit.Product set ProdName='shubham',Price=70,ExpDate= '12/12/1996' where id =3;

delete from Amit.Product where id=3;


insert into Amit.Product values (@pName,@price,@eDate);

create procedure Amit.USP_ProductInsert 
@pName varchar(20),
@price as decimal,
@eDate as Datetime
as
Begin
insert into Amit.Product values (@pName,@price,@eDate);
End

create procedure Amit.USP_ProductUpdate
@id as int,
@pName varchar(20),
@price as decimal,
@eDate as Datetime
as
Begin
update Amit.Product set ProdName=@pName,Price=@price,ExpDate=@eDate where id = @id;
End

create procedure Amit.USP_ProductDelete
@id as int
as
Begin
delete from Amit.Product where id=@id;
End

exec Amit.USP_ProductDelete 4