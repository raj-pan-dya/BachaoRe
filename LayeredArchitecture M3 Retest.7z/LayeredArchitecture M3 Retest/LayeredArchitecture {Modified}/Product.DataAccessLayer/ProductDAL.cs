﻿///<summary>
///      File                 : 
///      Author Name          : Amit Potdar
///      Desc                 : Program to define respective function in Data Access layer.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using Product.Entity;
using Product.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace Product.DataAccessLayer
{
    
    public class ProductDAL
    {
        //Declaring SqlConnection object reference
        SqlConnection con = null;
        
        //Declaring SqlCommand object reference
        SqlCommand cmd = null;

        //Declaring Data Reader object reference
        SqlDataReader dr = null;


        public ProductDAL()
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);
        }

        //DAL Method to insert data in product table using Stored Procedure 

        public bool InsertDAL(Product1 product)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("raju654.USP_ProductInsert", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pname", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                con.Open();
                cmd.ExecuteNonQuery();
                isInserted = true;
            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return isInserted;
        }

        //DAL Method to Update data in product table using Stored Procedure 

        public bool UpdateDAL(Product1 product)
        {
            bool isUpdated = false;

            try

            {
                cmd = new SqlCommand("Amit.USP_ProductUpdate", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pname", product.ProdName);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                con.Open();
                cmd.ExecuteNonQuery();
                isUpdated = true;
            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return isUpdated;
        }

        //DAL Method to Delete data from product table using Stored Procedure 

        public bool DeleteDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                cmd = new SqlCommand("Amit.USP_ProductDelete", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }

            return isDeleted;
        }

        //DAL Method to Select and populate data from product table 

        public IEnumerable<Product1> SelectDAL()
        {
            List<Product1> products = new List<Product1>();
            try
            {
                cmd = new SqlCommand("select * from Amit.Product", con);
                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product1 p = new Product1();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProdName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        products.Add(p);
                    }
                }
                dr.Close();

            }
            catch (Product_Exception ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            }
            return products;
        }


    }
}
