﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ListBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> lst = null;
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext=new List<string>{"MH","MP","Bihar" };
        }

        private void l1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

             update();

        }

        private void l2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (l2.SelectedValue.Equals("Pune")|| l2.SelectedValue.Equals("Nagpur") || l2.SelectedValue.Equals("Thane") || l2.SelectedValue.Equals("Mumbai"))
            {
                l1.ItemsSource = new List<string>{"MH" };
            }
            if (l2.SelectedValue.Equals("Bhopal") || l2.SelectedValue.Equals("Jabalpur") || l2.SelectedValue.Equals("Seoni") || l2.SelectedValue.Equals("Indore"))
            {
                l1.ItemsSource = new List<string> { "MP" };
            }
            if (l2.SelectedValue.Equals("Gaya") || l2.SelectedValue.Equals("Patna") || l2.SelectedValue.Equals("Deoghar") || l2.SelectedValue.Equals("Motihari"))
            {
                l1.ItemsSource = new List<string> { "Bihar" };
            }
        }
        public List<string> update()
        {
            
            if (l1.SelectedIndex == 0)
            {
                lst = new List<string> { "Pune", "Nagpur", "Mumbai", "Thane" };
                l2.ItemsSource = lst;
            }
            if (l1.SelectedIndex == 1)
            {
                lst = new List<string> { "Bhopal", "Jabalpur", "Seoni", "Indore" };
                l2.ItemsSource = lst;

            }                       
            if (l1.SelectedIndex == 2)
            {
                 lst = new List<string> { "Patna", "Motihari", "Deoghar", "Gaya" };
                l2.ItemsSource = lst;
            }
            return lst;
       }
    }
}
