﻿/*******************************************************
 File           : ProductDAL.cs    
 Desc           : ---
 Author         : Rudrendra Uday Ambike
 CreationDate   : 13 Dec 2018
 Version        : 1.0
 
 
 *******************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductManagementSystem.Entities;
using ProductManagementSystem.Exceptions;
using System.Data.SqlClient;
using System.Configuration;


namespace ProductManagementSystem.DataAccessLayer
{
    //Data Access Layer
    public class ProductDAL
    {
        //Declare SqlConnection object here
        SqlConnection sqlCn = null;

        //Declare SqlCommand object here
        SqlCommand sqlCmd = null;

        //Declare SqlDataReader object here
        SqlDataReader sqlDR = null;

        //Constructor is used here
        public ProductDAL()
        {
            sqlCn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        }

        //DAL Method to insert data in Product Table using Stored Procedure.

        public bool InsertDAL(Product product)
        {
            bool isInserted = false;

            try
            {
                sqlCmd = new SqlCommand("rudidemo.USP_InsertProduct", sqlCn);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@prodName", product.ProdName);
                sqlCmd.Parameters.AddWithValue("@price", product.Price);
                sqlCmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                sqlCn.Open();
                sqlCmd.ExecuteNonQuery();
                isInserted = true;


            }
            catch (ProductException px)
            {

                throw px;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlCn.State == System.Data.ConnectionState.Open)
                    sqlCn.Close();
            }
            return isInserted;
        }


        public bool DeleteDAL(int id)
        {
            bool isDeleted = false;
            try
            {
                sqlCmd = new SqlCommand("rudidemo.USP_DeleteProduct", sqlCn);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@id", id);
                sqlCn.Open();
                sqlCmd.ExecuteNonQuery();
                isDeleted = true;
            }
            catch (ProductException ps)
            {
                throw ps;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (sqlCn.State == System.Data.ConnectionState.Open)
                    sqlCn.Close();
            }

            return isDeleted;
        }


        public IEnumerable<Product> SelectDAL()
        {
            List<Product> products = new List<Product>();
            try
            {
                sqlCmd = new SqlCommand("select * from rudidemo.Product1", sqlCn);
                sqlCn.Open();
                sqlDR = sqlCmd.ExecuteReader();
                if (sqlDR.HasRows)
                {
                    while (sqlDR.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(sqlDR[0]);
                        p.ProdName = sqlDR[1].ToString();
                        p.Price = Convert.ToDecimal(sqlDR[2]);
                        p.ExpDate = Convert.ToDateTime(sqlDR[3]);
                        products.Add(p);
                    }
                }
                sqlDR.Close();

            }
            catch (ProductException px)
            {
                throw px;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (sqlCn.State == System.Data.ConnectionState.Open)
                    sqlCn.Close();
            }
            return products;
        }


        public bool UpdateDAL(Product product)
        {
            bool isUpdated = false;

            try

            {
                sqlCmd = new SqlCommand("rudidemo.USP_UpdateProduct", sqlCn);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@id", product.Id);
                sqlCmd.Parameters.AddWithValue("@prodName", product.ProdName);
                sqlCmd.Parameters.AddWithValue("@price", product.Price);
                sqlCmd.Parameters.AddWithValue("@eDate", product.ExpDate);
                sqlCn.Open();
                sqlCmd.ExecuteNonQuery();
                isUpdated = true;
            }
            catch (ProductException px)
            {
                throw px;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (sqlCn.State == System.Data.ConnectionState.Open)
                    sqlCn.Close();
            }
            return isUpdated;
        }

    }
}
