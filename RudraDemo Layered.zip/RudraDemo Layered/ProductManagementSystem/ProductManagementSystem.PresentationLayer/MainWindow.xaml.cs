﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ProductManagementSystem.Entities;
using ProductManagementSystem.Exceptions;
using ProductManagementSystem.BusinessLayer;

namespace ProductManagementSystem.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductBL prodBL = new ProductBL();
        Product prodTemp = null;
        public MainWindow()
        {
            InitializeComponent();
        }

        public void DisplayUI()
        {
            try
            {
                IEnumerable<Product> prods = prodBL.SelectBL();
                gridProducts.ItemsSource = prods;
                prodName.ItemsSource = prods;
                prodName.DisplayMemberPath = "ProdName";

            }
            catch (ProductException px)
            {
                MessageBox.Show(px.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);                
            }
        }

        private void Button_Insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsValidInput())
                {
                    Product prod = new Product
                    {
                        ProdName = prodName.Text,
                        Price = Convert.ToDecimal(textPrice.Text),
                        ExpDate = Convert.ToDateTime(datePicker.Text)

                    };

                    prodBL.InsertBL(prod);
                    MessageBox.Show("Inserted Succesfully");
                    DisplayUI();
                }
            }
            catch(ProductException px)
            {
                MessageBox.Show(px.Message);
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message);
            }
        }


        private void Button_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (IsValidInput())
                {
                    prodTemp.ProdName = prodName.Text;
                    prodTemp.Price = Convert.ToDecimal(textPrice.Text);
                    prodTemp.ExpDate = Convert.ToDateTime(datePicker.Text);
                    prodBL.UpdateBL(prodTemp);
                    MessageBox.Show("Update Succesfully");
                    DisplayUI();
                }

            }
            catch (ProductException px)
            {
                MessageBox.Show(px.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }


        }

        private void Button_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsValidInput())
                {
                    prodTemp = (Product)prodName.SelectedItem;

                    prodBL.DeleteBL(prodTemp.Id);
                    MessageBox.Show("Deleted Succesfully");
                    DisplayUI();
                }

            }
            catch (ProductException px)
            {
                MessageBox.Show(px.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            prodTemp = (Product)prodName.SelectedItem;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayUI();
        }

        private bool IsValidInput()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (prodName.Text == null | prodName.Text == string.Empty | prodName.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                isValid = false;
            }
            if (textPrice.Text == null | textPrice.Text == string.Empty | textPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (datePicker.Text.ToString() == null | datePicker.Text == string.Empty | datePicker.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new ProductException(sb.ToString());
            }

            return isValid;

        }

    }
}
    
