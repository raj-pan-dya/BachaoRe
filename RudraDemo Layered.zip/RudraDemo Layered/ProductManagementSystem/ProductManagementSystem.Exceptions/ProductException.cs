﻿/*******************************************************
 File           : ProductException.cs    
 Desc           : ---
 Author         : Rudrendra Uday Ambike
 CreationDate   : 13 Dec 2018
 Version        : 1.0
 
 
 *******************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagementSystem.Exceptions
{
    public class ProductException:ApplicationException
    {
        //UserDefined Exception Classes
        public ProductException()
            :base()
        {

        }
        public ProductException(string message)
            :base(message)
        {

        }
    }
}
