﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductManagementSystem.Entities;
using ProductManagementSystem.Exceptions;
using ProductManagementSystem.DataAccessLayer;

namespace ProductManagementSystem.BusinessLayer
{
    public class ProductBL
    {
        //checking the validations
        private static bool IsValidInput(Product product)
        {
            //Creating object of StringBuilder class
            StringBuilder sBuilder = new StringBuilder();

            bool productValid = true;
            if(product.ProdName.Length < 2)
            {
                productValid = false;
                sBuilder.Append(Environment.NewLine + "Product Name Invalid");
            }
            if(product.Price < 0)
            {
                productValid = false;
                sBuilder.Append(Environment.NewLine + "Price is Invalid");
            }
            if (product.ExpDate.Date <= (DateTime.Now.Date))
            {
                productValid = false;
                sBuilder.Append(Environment.NewLine + "Expired Product");
            }
            if (productValid == false)
                throw new ProductException(sBuilder.ToString());
            return productValid;
        }

        //Method of BL to insert data in product table using stored procedure

        public bool InsertBL(Product product)
        {
            bool isInserted = false;
            try
            {
                if (IsValidInput(product))
                {
                    ProductDAL prodDAL = new ProductDAL();
                    isInserted = prodDAL.InsertDAL(product);
                }
            }
            catch(ProductException px)
            {
                throw px;
            }
            catch (Exception ex)
            {

                throw ex;
            }
          
            return isInserted;
        }

        public IEnumerable<Product> SelectBL()
        {
            IEnumerable<Product> products = null;
            try
            {

                ProductDAL proDL = new ProductDAL();
                products = proDL.SelectDAL();

            }
            catch (ProductException px)
            {
                throw px;
            }
            catch (Exception)
            {
                throw;
            }

            return products;

        }



        public bool DeleteBL(int id)
        {
            bool isDeleted = false;

            try
            {
                ProductDAL prodDAL = new ProductDAL();
                isDeleted = prodDAL.DeleteDAL(id);

            }
            catch (ProductException px)
            {
                throw px;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isDeleted;
        }
        public bool UpdateBL(Product product)
        {
            bool isUpdated = false;
            try
            {
                if (IsValidInput(product))
                {
                    ProductDAL proDAL = new ProductDAL();
                    isUpdated = proDAL.UpdateDAL(product);

                }
            }
            catch (ProductException px)
            {
                throw px;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
            }
            return isUpdated;
        }

    }
}
