﻿/*******************************************************
 File           : Product.cs    
 Desc           : ---
 Author         : Rudrendra Uday Ambike
 CreationDate   : 13 Dec 2018
 Version        : 1.0
 
 
 *******************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagementSystem.Entities
{
    public class Product
    {
        //Properties are defined

        public int Id { get; set; }
        public string ProdName{ get; set; }
        public decimal Price { get; set; }
        public DateTime ExpDate { get; set; }
    }
}
