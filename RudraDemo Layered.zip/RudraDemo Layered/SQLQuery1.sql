﻿--Schema is created here
create schema rudidemo;

drop procedure rudidemo.USP_UpdateProduct
--now create table with given requirements
create table [rudidemo].[Product1](
[Id] int identity (1,1) primary key not null,
[ProdName] varchar(20) null,
[Price] decimal (18) null,
[ExpDate] Date null

); 

-- Inserting Records into Product1 Table
insert into rudidemo.Product1 values('Rudrendra',150,'12/12/2018'),('Raju',490,'10/26/2018');

--Display records from table
select * from rudidemo.Product1;

--create Stored Procedure
drop 

create procedure rudidemo.USP_InsertProduct
@prodName varchar(20),
@price  decimal,
@eDate Datetime
as
Begin
insert into rudidemo.Product1 values(@prodName,@price,@eDate);
End

--exec USP_InsertProduct 'rud',20,'12/12/2017';

create proc rudidemo.USP_UpdateProduct
@id int,
@prodName varchar(20),
@price decimal,
@eDate Datetime
as
Begin
update rudidemo.Product1 set ProdName=@prodName,Price=@price,ExpDate=@eDate where id=@id;
End

create proc rudidemo.USP_DeleteProduct
@id int
as
Begin
delete from rudidemo.Product1 where id=@id;
End
