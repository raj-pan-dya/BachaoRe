﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Demo1
{
    class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public int[] Marks { get; set; }
        public int Age { get; set; }

        public static List<Student> GetAll()
        {
            List<Student> students = new List<Student>
            {
                new Student { RollNo = 101, Name = "Siddhesh", Marks = new int[]{ 40, 55, 44, 54}, Age = 21 },
                new Student { RollNo = 102, Name = "Shariq", Marks = new int[]{ 41, 45, 46, 56}, Age = 23 },
                new Student { RollNo = 103, Name = "Amit", Marks = new int[]{ 42, 56, 64, 53}, Age = 22 },
                new Student { RollNo = 104, Name = "Raju", Marks = new int[]{ 44, 46, 34, 55}, Age = 23 }
            };
            return students;
        }
    }
}
