﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] number = new int[7] { 01, 20, 32, 34, 12, 23, 34 };

            ////    //var res = from n in number
            ////    //          where (n % 2 == 0)
            ////    //          select n;

            ////    /***** Syntax using extension methods (Lamda expression) *****/
            //var res = number.Where(n => n % 2 == 0);

            //    foreach (var i in res)
            //    {
            //        Console.Write(i);
            //    }

            //    number[1] = 9;

            //    Console.Write("\n");

            //    foreach (var item in res)
            //    {
            //        Console.Write(item);
            //    }

            List<Student> students = Student.GetAll();

            //var res = from s in students
            //          select new { s.RollNo, s.Name };

            //foreach (var item in res)
            //{
            //    Console.WriteLine(item.RollNo + " " + item.Name);
            //}

            //var res = from s in students
            //          from p in s.Marks
            //          select p;                      

            //var res = students.SelectMany(n => n.Marks);

            //foreach (var item in res)
            //{
            //    Console.Write(item + ", ");
            //}

            //var res = from s in students
            //          orderby s.Age
            //          select s;

            //var res = students.OrderByDescending(n => n.Age).ThenBy(n => n.Name); //.Reverse();

            //foreach (var item in res)
            //{
            //    Console.WriteLine(item.RollNo + ", " + item.Name);
            //}

            //var res = from t in students
            //          group t by t.Age;

            //foreach (var item in res)
            //{
            //    Console.WriteLine("Age Group" + item.Key);
            //    foreach (var dt in item)
            //    {
            //        Console.WriteLine(dt.RollNo + ", " + dt.Name + ", " + dt.Age);                    
            //    }
            //    Console.WriteLine("******************************************");
            //}

            int[] arr1 = { 1, 2, 3, 4, 5 };
            int[] arr2 = new int[0];

            //var res1 = arr1.Union(arr2);
            //foreach (var i in res1)
            //{
            //    Console.WriteLine("Union" + i);
            //}

            //var res2 = arr1.Intersect(arr2);
            //foreach (var i in res2)
            //{
            //    Console.WriteLine("Intersect" + i);
            //}

            //var res3 = arr1.Except(arr2);
            //foreach (var item in res3)
            //{
            //    Console.WriteLine("Except" + item);
            //}

            //object[] objs = { 1, 'C', "Hello", 1.5, 5, "Hi", 'A' };
            //var elms = objs.OfType<int>();
            //foreach (var i in elms)
            //{
            //    Console.WriteLine(i);
            //}

            //Console.WriteLine("Sum " + arr1.Sum());
            //Console.WriteLine("Largest no " + arr1.Max());
            //Console.WriteLine("Smallest no " + arr1.Min());
            //Console.WriteLine("Average " + arr1.Average());

            //Console.WriteLine("First: " + arr1.First());
            //Console.Write("FirstOrDefault: " + arr2.FirstOrDefault());

            //Console.WriteLine("Last: " + arr1.Last());
            //Console.WriteLine("LastOrDefault: " + arr2.LastOrDefault());

            //var res1 = students.Where(s => s.RollNo == 101);

            //Console.WriteLine("Single: " + arr1.Single());

            //Console.WriteLine("SingleOrDefault: " + arr1.SingleOrDefault());

            /***** Get roll no, Name of students starting name with 'S' *****/
            //var res2 = students.Where(s => s.Name.StartsWith("S")).Select(s => new { studName = s.Name, rNo = s.RollNo });
            //foreach (var i in res2)
            //{
            //    Console.WriteLine(i.studName + ", " + i.rNo);
            //}

            

            Console.ReadKey();
        }
    }
}
