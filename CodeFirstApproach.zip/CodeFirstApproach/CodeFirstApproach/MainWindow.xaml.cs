﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodeFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Product_Db proDb = null;
        public MainWindow()
        {
            InitializeComponent();
            proDb = new Product_Db();
        }
        public void Insert()
        {
            Product_567 pro = new Product_567
            {
                Id = 5,
                ProdName = "Amit",
                ExpDate =Convert.ToDateTime( "10,12,2015"),
                Price = 5

            };
            proDb.Products.Add(pro);
            proDb.SaveChanges();
            MessageBox.Show("Inserted");
        }
       
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Insert();
        }
    }
}
