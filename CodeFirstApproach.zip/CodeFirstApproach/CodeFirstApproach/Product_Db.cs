﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CodeFirstApproach
{
    public class Product_Db : DbContext
    {
        public Product_Db()
            : base("name=con")
        {

        }

        public virtual DbSet<Product_567> Products{ get; set; }
    }
}
