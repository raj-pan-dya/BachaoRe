﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.ComponentModel.DataAnnotations;

namespace CodeFirstApproach
{
    public class Product_567
    {
       
        public int Id { get; set; }
        public string ProdName { get; set; }
        public Decimal Price { get; set; }
        public DateTime ExpDate { get; set; }
    }
}
