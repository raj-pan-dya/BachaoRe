﻿///<summary>
///      File                 : Person.cs
///      Author Name          : Amit Potdar
///      Desc                 : Creating of Person Class
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person
{
    // Class name Person
    public class Person
    {
        // Writing all the fields and properties as per requirements
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private int _age;

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
        private int _salary;

        public int Salary
        {
            get { return _salary; }
            set { _salary = value; }
        }
    }
}
