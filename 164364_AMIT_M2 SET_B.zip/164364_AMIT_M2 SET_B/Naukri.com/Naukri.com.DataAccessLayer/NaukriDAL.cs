﻿///<summary>
///      File                 : NaukriDAL.cs
///      Author Name          : Amit Potdar
///      Desc                 : Program to define respective function in Data Access layer.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.com.Entities;
using Naukri.com.Exceptions;

namespace Naukri.com.DataAccessLayer
{
    [Serializable]
    public class NaukriDAL
    {

        public static List<JobSeekers> jobSeekers = new List<JobSeekers>();

        // Function to add new Job Seekers

        public bool AddGuestDAL(JobSeekers newJobSeeker)
        {
            bool newJobSeekerAdded = false;
            try
            {
                jobSeekers.Add(newJobSeeker);
                newJobSeekerAdded = true;
            }
            catch (SystemException ex)
            {
                throw new NaukriException(ex.Message);
            }
            return newJobSeekerAdded;

        }

         

        //Function to search job Seekers  by City.
        public List<JobSeekers> SearchByCityDAL(String city)
        {
            
                List<JobSeekers> searchJS = new List<JobSeekers>();
                try
                {
                    searchJS.Add(jobSeekers.Find(jobSeeker => jobSeeker.City.Equals(city)));
                }
                catch (SystemException ex)
                {
                    throw new NaukriException(ex.Message);
                }
                return searchJS;
            
        }
       

    }
}

