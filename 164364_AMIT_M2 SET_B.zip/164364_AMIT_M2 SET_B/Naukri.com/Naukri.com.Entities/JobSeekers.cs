﻿///<summary>
///      File                 : JobSeekers.cs
///      Author Name          : Amit Potdar
///      Desc                 : Program to define the Entities of the project.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Naukri.com.Entities
{
    [Serializable]
    public class JobSeekers
    {
        private string _name;

        // Defintion of Properties as per requirements

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private string _qualification;

        public string Qualification
        {
            get { return _qualification; }
            set { _qualification = value; }
        }
        private int _mobile;

        public int Mobile
        {
            get { return _mobile; }
            set { _mobile = value; }
        }

        private string _city;
        public string City
        {
            get { return _city; }
            set { _city = value; }
        }

        private DateTime _dob;
        public DateTime DOB
        {
            get { return _dob; }
            set { _dob = value; }
        }


        // Constructor to initialize the memebers.

        public JobSeekers()
        {
            _name = string.Empty;
            _qualification = string.Empty;
            _mobile = 0;
            _city = string.Empty;
         
        }


    }
}
