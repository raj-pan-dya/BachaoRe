﻿///<summary>
///      File                 : 
///      Author Name          : Amit Potdar
///      Desc                 : Program to define the Entities of the project.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.com.Entities;
using Naukri.com.Exceptions;
using Naukri.com.DataAccessLayer;

namespace Naukri.com.BusinessLayer
{
    public class NaukriBL
    {
        // Function to validate user

        private static bool ValidateGuest(JobSeekers jobSeekers)
        {
            StringBuilder sb = new StringBuilder();
            bool validJS = true;
            if (jobSeekers.Name == string.Empty)
            {
                validJS = false;
                sb.Append(Environment.NewLine + "Name Required");

            }
            if (!(jobSeekers.City.Equals("Mumbai")|| jobSeekers.City.Equals("Pune") || jobSeekers.City.Equals( "Chennai") || jobSeekers.City.Equals("Bangalore") ))
            {
                validJS = false;
                sb.Append(Environment.NewLine + "Invalid City \n City can be Mumbai,Pune,Chennai,Bangalore");

            }
            
            if (jobSeekers.Mobile.ToString().Length != 10)
            {
                validJS = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            if (!(jobSeekers.Qualification.Equals("BE") || jobSeekers.Qualification.Equals("ME") || jobSeekers.Qualification.Equals("MCA")))
            {
                validJS = false;
                sb.Append(Environment.NewLine + "Invalid Qualification Qualification can be BE, ME,MCA ");
            }
            if (validJS == false)
                throw new NaukriException(sb.ToString());
            return validJS;
        }
        // Function to write logic to add new guests.

        public static bool AddJS(JobSeekers newJS)
        {
            bool jSAdded = false;
            try
            {
                if (ValidateGuest(newJS))
                {
                    NaukriDAL jsDAL = new NaukriDAL();
                    jSAdded = jsDAL.AddGuestDAL(newJS);
                }
            }
            catch (NaukriException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return jSAdded;
        }
        // Function to write logic to search a guest by guest ID.

        public static List<JobSeekers> SearchByCityBL(string city)
        {
           List<JobSeekers> searchjs =  new List<JobSeekers>();
            try
            {
                NaukriDAL jsDAL = new NaukriDAL();
                searchjs = jsDAL.SearchByCityDAL(city);
            }
            catch (NaukriException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchjs;

        }
    }
}
